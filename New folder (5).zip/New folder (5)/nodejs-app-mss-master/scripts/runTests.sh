#!/usr/bin/env sh

echo 'The following "npm" command will run the test cases.'

npm test
